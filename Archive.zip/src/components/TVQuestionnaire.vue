<script setup>
import { ref, watch } from "vue";
import DataTable from "primevue/datatable";
import Column from "primevue/column";
import Select from "primevue/select";

const props = defineProps({
  postes: {
    type: Array,
    required: true,
  },
  childOptions: {
    type: Array,
    required: true, // Dynamically generated options for "etat" and "activite"
  },
});

const emit = defineEmits(["update-poste-data"]);
const posteData = ref([]);

// Define the mapping for emplacement with integer values
const emplacementOptions = [
  { label: "Salon", value: 1 },
  { label: "Séjour", value: 2 },
  { label: "Chambre à coucher", value: 3 },
  { label: "Cuisine", value: 4 },
  { label: "Autre chambre", value: 5 },
];

// Helper function to map emplacement value to its label
const mapEmplacement = (value) => {
  const option = emplacementOptions.find((opt) => opt.value === value);
  return option ? option.label : "Unknown";
};

// Initialize posteData and populate rows with additional childOptions
const initializePosteData = () => {
  if (!props.postes || props.postes.length === 0) {
    posteData.value = []; // Handle empty or undefined postes
    return;
  }
  posteData.value = props.postes.map((poste) => {
    const row = { ...poste };
    props.childOptions.forEach((option) => {
      if (!row[option.id]) {
        row[option.id] = { id: option.id, code: "", value: "" };
      }
    });
    return row;
  });
  emit("update-poste-data", posteData.value);
};

// Watch for changes in postes and reinitialize data
watch(
  () => props.postes,
  () => {
    initializePosteData();
  },
  { immediate: true }
);

// Watch for changes in posteData and emit updates to parent
watch(
  posteData,
  (newData) => {
    emit("update-poste-data", formatPosteData(newData));
  },
  { deep: true }
);

// Format posteData to include only relevant fields for submission
const formatPosteData = (data) => {
  return data.map((row) => {
    const formattedRow = { id_poste: row.id_poste, num_poste: row.num_poste, emplacement: row.emplacement };
    props.childOptions.forEach((option) => {
      formattedRow[option.id] = row[option.id].value; // Use the selected value
    });
    return formattedRow;
  });
};

// Update specific cell data for posteData
const updatePosteData = (posteId, optionId, value) => {
  const poste = posteData.value.find((row) => row.id_poste === posteId);
  if (poste) {
    poste[optionId].value = value.code; // Update selected value
    emit("update-poste-data", formatPosteData(posteData.value));
  }
};
</script>

<template>
  <div>
    <h3>Poste Information</h3>
    <DataTable :value="posteData" editMode="cell" class="editable-datatable">
      <!-- Display ID, Num, and Emplacement -->
      <Column field="id_poste" header="Poste ID" :sortable="true" />
      <Column field="num_poste" header="Poste Number" :sortable="true" />
      <Column field="emplacement" header="Emplacement" :sortable="true">
        <template #body="slotProps">
          {{ mapEmplacement(slotProps.data.emplacement) }}
        </template>
        <template #editor="slotProps">
          <Select
            v-model="slotProps.data.emplacement"
            :options="emplacementOptions"
            optionLabel="label"
            optionValue="value"
            placeholder="Select Emplacement"
          />
        </template>
      </Column>

      <!-- Dynamically render additional columns based on childOptions -->
      <Column v-for="option in childOptions" :key="option.id" :field="option.id" :header="option.label">
        <template #body="slotProps">
          <Select
            v-model="slotProps.data[option.id].value"
            :options="option.options"
            optionLabel="value"
            optionValue="code"
            placeholder="Select"
            @change="updatePosteData(slotProps.data.id_poste, option.id, slotProps.data[option.id])"
          />
        </template>
      </Column>
    </DataTable>
  </div>
</template>
