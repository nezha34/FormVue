<template>
    <div class="dynamic-table">
      <DataTable
        :value="data || []"
        editMode="cell"
        :rowClass="rowClass"
        :rowStyle="rowStyle"
        @cell-edit-complete="onCellEditComplete"
        tableStyle="min-width: 50rem"
      >
        <!-- Dynamic Columns -->
        <Column
          v-for="(column, index) in columns"
          :key="index"
          :field="column.field"
          :header="column.header"
          :style="{ width: '20%' }"
        >
          <template #body="{ data, field }">
            {{ data[field] }}
          </template>
        </Column>
  
        <!-- Activite Column with Slot -->
        <Column field="activite" header="Activité">
          <template #body="slotProps">
            <Select
              v-model="slotProps.data.activite"
              :options="activiteOptions"
              optionLabel="label"
              optionValue="value"
              placeholder="Select"
              @change="updateActivite(slotProps.data)"
            />
          </template>
        </Column>
  
        <!-- Statut Column with Slot -->
        <Column field="statut" header="Statut">
          <template #body="slotProps">
            <Select
              v-model="slotProps.data.statut"
              :options="statutOptions"
              optionLabel="label"
              optionValue="value"
              placeholder="Select"
              @change="updateStatut(slotProps.data)"
            />
          </template>
        </Column>
      </DataTable>
    </div>
  </template>
  
  <script setup>
  import { ref } from "vue";
  import DataTable from "primevue/datatable";
  import Column from "primevue/column";
  import Select from "primevue/select";
  
  const props = defineProps({
    data: {
      type: Array,
      default: () => [], // Ensure default as array
    },
    columns: {
      type: Array,
      default: () => [], // Ensure default as array
    },
    uniqueKey: {
      type: String,
      required: true,
    },
  });
  
  const emit = defineEmits(["update"]);
  
  const activiteOptions = [
    { label: "Regarde TV", value: "Regarde TV" },
    { label: "Ne Regarde Pas TV", value: "Ne Regarde Pas TV" },
  ];
  
  const statutOptions = [
    { label: "Actif", value: "Actif" },
    { label: "Sortie", value: "Sortie" },
  ];
  
  const onCellEditComplete = (event) => {
    const { data, newValue, field } = event;
  
    if (!data || !field) {
      console.error("Invalid data or field:", { data, field });
      return;
    }
  
    emit("update", { ...data });
  };
  
  const updateActivite = (rowData) => {
    emit("update", { ...rowData });
  };
  
  const updateStatut = (rowData) => {
    emit("update", { ...rowData });
  };
  
  const rowStyle = (data) => {
    return data.chef_menage === true
      ? { fontWeight: "bold", fontStyle: "italic", backgroundColor: "lightcoral" }
      : data.maman === true
      ? { fontWeight: "normal", fontStyle: "italic", backgroundColor: "lightpink" }
      : { fontWeight: "normal", fontStyle: "normal", backgroundColor: "white" };
  };
  </script>
  
  <style scoped>
  .highlight-row {
    background-color: #b04545 !important;
    font-weight: bold;
  }
  </style>
  