<template>
    <div class="guest-table-container">
      <div class="field">
        <label for="guestCount">Number of Guests:</label>
        <InputText
          v-model.number="guestCount"
          id="guestCount"
          type="number"
          placeholder="Enter number of guests"
          min="0"
          @change="generateGuestRows"
        />
      </div>
      <DataTable :value="guests" class="editable-datatable">
        <Column field="name" header="Nom / Prénom">
          <template #body="slotProps">
            <InputText
              v-model="slotProps.data.name"
              placeholder="Enter Name"
            />
          </template>
        </Column>
        <Column field="age" header="Age">
          <template #body="slotProps">
            <InputText
              v-model="slotProps.data.age"
              type="number"
              placeholder="Enter Age"
            />
          </template>
        </Column>
        <Column field="sex" header="Sexe">
          <template #body="slotProps">
            <InputText
              v-model="slotProps.data.sex"
              placeholder="Enter Sex"
            />
          </template>
        </Column>
        <Column field="activity" header="N° Touche">
          <template #body="slotProps">
            <InputText
              v-model="slotProps.data.activity"
              placeholder="Enter Activity"
            />
          </template>
        </Column>
        <Column field="tvLocation" header="Emplacement de la TV">
          <template #body="slotProps">
            <InputText
              v-model="slotProps.data.tvLocation"
              placeholder="Enter TV Location"
            />
          </template>
        </Column>
      </DataTable>
    </div>
  </template>
  
  <script setup>
  import { ref, watch } from "vue";
  import DataTable from "primevue/datatable";
  import Column from "primevue/column";
  import InputText from "primevue/inputtext";
  
  // Props to accept initial guest data
  const props = defineProps({
    initialGuests: {
      type: Array,
      default: () => [],
    },
  });
  
  // Emit updates to parent
  const emit = defineEmits(["update-guests"]);
  
  // Reactive data
  const guestCount = ref(props.initialGuests.length || 0);
  const guests = ref([...props.initialGuests]);
  
  // Generate rows dynamically
  const generateGuestRows = () => {
    const focusedElement = document.activeElement; // Save the current focus

    const newGuests = Array.from({ length: guestCount.value }, (_, i) => ({
      id: i + 1,
      name: "",
      age: "",
      sex: "",
      activity: "",
      tvLocation: "",
    }));
  
    guests.value = newGuests;
    emit("update-guests", newGuests);
    if (focusedElement && focusedElement.tagName === "INPUT") {
    focusedElement.focus();
  }
  };
  
  // Sync with parent component when props change
  watch(
  () => props.initialGuests,
  (newGuests) => {
    // Update only new or changed rows
    newGuests.forEach((guest, index) => {
      if (guests.value[index]) {
        Object.assign(guests.value[index], guest); // Merge data
      } else {
        guests.value.push(guest); // Add new guests
      }
    });

    // Adjust guest count
    guestCount.value = newGuests.length;
  },
  { deep: true }
);

  let emitTimeout;
watch(
  guests,
  (updatedGuests, oldGuests) => {
    if (JSON.stringify(updatedGuests) !== JSON.stringify(oldGuests)) {
      if (emitTimeout) clearTimeout(emitTimeout); // Clear previous timeout
      emitTimeout = setTimeout(() => {
        emit("update-guests", updatedGuests); // Emit with debounce
      }, 200); // Adjust debounce time as needed
    }
  },
  { deep: true }
);

  </script>
  
  <style scoped>
  .guest-table-container {
    margin-top: 1rem;
  }
  
  .editable-datatable {
    margin-top: 20px;
  }
  
  .field {
    margin-bottom: 1rem;
  }
  </style>
  