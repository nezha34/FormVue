<template>
  <div class="question-container">
    <!-- Ensure each label's 'for' attribute matches the input's 'id' -->
    <label :for="`question-${question.id}`">{{ question.question }}</label>

    <!-- Render boolean options with default Yes/No if options are missing -->
    <template v-if="question.type === 'boolean'">
      <div class="p-buttonset">
        <Button 
          v-for="option in question.options || ['Yes', 'No']" 
          :key="option" 
          @click="setAnswer(option)" 
          size="small">
          {{ option }}
        </Button>
      </div>
    </template>

    <!-- Render text input with unique id -->
    <input 
      v-if="question.type === 'text'" 
      :id="`question-${question.id}`" 
      v-model="localAnswer" 
      placeholder="Enter your response" 
      @input="updateAnswer" 
    />

    <!-- Render number input with unique id -->
    <!--<input 
      v-if="question.type === 'number'" 
      :id="`question-${question.id}`" 
      type="number" 
      v-model="localAnswer" 
      placeholder="Enter a number" 
      @input="updateAnswer" 
    />-->

        <!-- Render cascade input with unique id -->
        <Select
      v-if="question.type === 'cascade'"
      :id="`question-${question.id}`"
      v-model="localAnswer"
      :options="cascadeOptions"
      optionLabel="label"
      placeholder="Select an option"
      @change="updateAnswer"
    />



    <!-- Recursively render child questions only if the answer is 'Yes' -->
    <div v-if="question.children && localAnswer === 'Yes'" class="p-ml-3">
      <div v-for="child in Object.values(question.children)" :key="child.id" class="p-field p-mb-2">
        <QuestionComponent :question="child" :answers="answers" @set-answer="$emit('set-answer', $event[0], $event[1])" />
      </div>
    </div>


    
  </div>
</template>

<script>
import Button from 'primevue/button';
import Select from 'primevue/select';
export default {
  props: {
    question: Object,
    answers: Object,
  },
  data() {
    return {
      localAnswer: this.answers[this.question.id] || '',
    };
  },
  computed: {
    cascadeOptions() {
      // Check if question.options is defined and formatted correctly for CascadeSelect
      return this.question.options?.map(option => ({ label: option, value: option })) || [];
    },
  },
  methods: {
    setAnswer(option) {
      this.localAnswer = option;
      this.$emit('set-answer', this.question.id, option);
    },
    updateAnswer() {
      this.$emit('set-answer', this.question.id, this.localAnswer);
    },
  },
  components: {
    Button,
    Select,
  },
  watch: {
    answers: {
      handler(newAnswers) {
        this.localAnswer = newAnswers[this.question.id] || '';
      },
      immediate: true,
      deep: true,
    },
  },
};
</script>

<style scoped>
.question-container {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 15px;
  margin-bottom: 20px;
  background-color: #f9fafe;
  border: 1px solid #e0e6ef;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
}

.question-label {
  font-size: 1rem;
  color: #333;
  font-weight: 600;
  margin-bottom: 8px;
}

.p-buttonset {
  margin: auto;
  gap: 10px;
  justify-content: flex-start;
}

.option-button {
  padding: 8px 16px;
  border-radius: 8px;
  border: none;
  background-color: #e6f3ff;
  color: #007bff;
  font-weight: 500;
  cursor: pointer;
  gap: 10;
  transition: background-color 0.3s, color 0.3s;
}

.option-button.selected {
  background-color: #007bff;
  color: white;
}

.option-button:hover {
  background-color: #005bb5;
  color: white;
}

.input-text,
.input-number {
  padding: 10px;
  border: 1px solid #d1d9e6;
  border-radius: 8px;
  width: 100%;
  font-size: 1rem;
  color: #333;
  background-color: #f9fafe;
  transition: border-color 0.3s, box-shadow 0.3s;
}

.input-text:focus,
.input-number:focus {
  border-color: #007bff;
  box-shadow: 0 4px 8px rgba(0, 123, 255, 0.1);
  outline: none;
}

.nested-question {
  margin-left: 20px;
  margin-top: 10px;
}
</style>
