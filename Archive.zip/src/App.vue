<template>
  <div class="form-container p-4 flex flex-row">
    <Toast />

    <ConfirmDialog />
    <div class="flex flex-row">
      <!-- Main Content -->
      <div class="main-content flex-grow-1 pr-4">
        <div class="flex justify-content-between align-items-center mb-4">
          <h1 class="text-3xl font-bold">Formulaire</h1>
          <Button label="Client Unavailable" icon="pi pi-times" class="p-buttonset" @click="setClientUnavailable"
            :class="{ disabled: isUnavailable }" />
        </div>



        <div v-if="isUnavailable" class="unavailable-reason">
          <label for="reason">Reason for Unavailability:</label>
          <Select v-model="unavailableReason"
            :options="['Moins de 15ans', 'Pas un membre du foyer', 'Refus', 'Pas Disponible/Prendre un rendez-vous']"
            placeholder="Select Reason" @change="console.log(unavailableReason)" />
          <Button v-if="unavailableReason === 'Pas Disponible/Prendre un rendez-vous'" type="button"
            icon="pi pi-calendar" label="Schedule Rendez-vous" class="p-button-success w-64" @click="toggle" />
        </div>
        <Popover ref="op" class="rounded-lg shadow-lg bg-white border border-gray-200 w-[20rem]">
          <div class="flex flex-col p-6 gap-4">
            <h3 class="text-lg font-semibold text-gray-700">Schedule a Rendezvous</h3>
            <div class="flex flex-col gap-2">
              <DatePicker v-model="appointment.date" id="date" class="border rounded-md p-2 w-full text-gray-800"
                showTime hourFormat="24" placeholder=" Date and Time" fluid />
            </div>
            <div class="flex justify-end gap-4 mt-4">
              <Button label="Cancel" icon="pi pi-times" class="p-button-outlined p-button-danger"
                @click="closePopover" />
              <Button label="Confirm" icon="pi pi-check" class="p-button-success" @click="confirmRendezvous" />
            </div>
          </div>
        </Popover>

        <Card title="Informations Générales Foyer" v-show="!isUnavailable" class="mb-4 ">
          <div class="foyer-info-horizontal p-4"
            style="border-radius: 10px; background-color: #f9fafb; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.05); width: 90%; margin: auto;">
            <div class="flex justify-content-between align-items-center" style="gap: 2rem; flex-wrap: wrap;">

              <!-- Foyer ID -->
              <div class="flex flex-column align-items-center text-center">
                <strong class="mb-1">Foyer ID:</strong>
                <span>{{ foyerData[currentFoyerIndex]?.no_foyer || 'N/A' }}</span>
              </div>

              <!-- Lieu Residence -->
              <div class="flex flex-column align-items-center text-center">
                <strong class="mb-1">Lieu Residence:</strong>
                <span>{{ foyerData[currentFoyerIndex]?.adresse || 'N/A' }}</span>
              </div>

              <!-- Taille Foyer -->
              <div class="flex flex-column align-items-center text-center">
                <strong class="mb-1">Taille Foyer:</strong>
                <span>{{ foyerData[currentFoyerIndex]?.taille_foyer || 'N/A' }}</span>
              </div>

              <div class="flex flex-column align-items-center text-center">
                <strong class="mb-1">Tel:</strong>
                <span>{{ foyerData[currentFoyerIndex]?.tel || 'N/A' }}</span>
              </div>

              <div class="flex flex-column align-items-center text-center">
                <strong class="mb-1">Mobile 1:</strong>
                <span>{{ foyerData[currentFoyerIndex]?.mobile1 || 'N/A' }}</span>
              </div>

              <div class="flex flex-column align-items-center text-center">
                <strong class="mb-1">Mobile 2:</strong>
                <span>{{ foyerData[currentFoyerIndex]?.mobile2 || 'N/A' }}</span>
              </div>

            </div>
          </div>
        </Card>



        <div v-show="!isUnavailable" class="main-content">



          <!-- Stepper and form section -->
          <div class="form-steps">
            <Stepper v-model:value="activeStep" class="basis-[40rem]">
              <StepList>
                <Step v-slot="{ activateCallback }" :value="1" @click="activateCallback(1)">Foyer
                </Step>
                <Step v-slot="{ activateCallback }" :value="2" @click="activateCallback(2)">Individu
                </Step>
                <Step v-slot="{ activateCallback }" :value="3" @click="activateCallback(4)">Informations Supplémentaires
                </Step>
              </StepList>
              <StepPanels class="form-steps">
                <!-- Step 1: Foyer -->
                <StepPanel v-slot="{ activateCallback }" :value="1">
                  <Card title="Household Information" icon="pi-home">
                    <div id="household-info-container">
                      <!-- Render root question from the tree -->
                      <div v-if="questionsTree.question">
                        <p>{{ questionsTree.question }}</p>
                        <!-- Check for type to render appropriately -->
                        <template v-if="questionsTree.type === 'boolean'">
                          <div class="p-buttonset">
                            <Button v-for="option in questionsTree.options || ['Yes', 'No']" :key="option"
                              @click="setAnswer(questionsTree.id, option)" size="small">
                              {{ option }}
                            </Button>
                          </div>
                          <!-- Show child questions if 'Yes' is selected -->
                          <div v-if="answers[questionsTree.id] === 'Yes'">
                            <div v-for="child in questionsTree.children['Yes']" :key="child.id">
                              <QuestionComponent :question="child" :answers="answers" @set-answer="setAnswer" />
                            </div>
                          </div>
                        </template>

                        <template v-else-if="questionsTree.type === 'text'">
                          <input v-model="answers[questionsTree.id]" placeholder="Enter your response"
                            @input="updateAnswer(questionsTree.id, answers[questionsTree.id])" class="input-text" />
                        </template>
                        <template v-else-if="questionsTree.type === 'select'">
                          <select v-model="answers[questionsTree.id]" placeholder="Membres foyer">
                            <option disabled value="">{{ placeholder }}</option>

                            <option v-for="member in filteredMembers" :key="member.id_indiv" :value="member.id_indiv">
                              {{ member.nom + " " + member.prenom }}
                            </option>
                          </select>
                        </template>
                      </div>

                      <!-- Render permanent child questions -->
                      <div v-for="question in questionsTree.permanentChildren" :key="question.id">
                        <!-- Check for boolean questions with options -->
                        <template v-if="question.type === 'boolean' && String(question.id) !== '7'">
                          <p>{{ question.question }}</p>
                          <div class="p-buttonset">
                            <Button v-for="option in question.options || ['Yes', 'No']" :key="option"
                              @click="setAnswer(question.id, option)" size="small">
                              {{ option }}
                            </Button>
                          </div>
                          <!-- Render guests table when "Yes" is selected -->
                          <div v-if="answers[question.id] === 'Yes'">
                            <GuestTable :initialGuests="guests" @update-guests="updateGuestData" />
                          </div>
                        </template>

                        <!-- Render child questions for non-boolean questions -->
                        <template v-if="question.type === 'number'">
                          <QuestionComponent :question="question" :answers="answers" @set-answer="setAnswer" />
                          <div v-if="question.id === '2' && question.children && question.children.length > 0">
                            <TVQuestionnaire :postes="filterePostes || []" :childOptions="question.children"
                              @update-poste-data="handlePosteUpdate" />
                          </div>
                        </template>
                      </div>
                    </div>

                    <div class="flex pt-6 justify-between">
                      <Button label="Next" icon="pi pi-arrow-right" iconPos="right" @click="activateCallback(2)" />
                    </div>
                  </Card>
                </StepPanel>


                <!-- Step 2: Individu (Multiple Members) -->
                <StepPanel v-slot="{ activateCallback }" :value="2">
                  <Card title="Individu Information" icon="pi-users">
                    <div class="panel-content">
                      <template v-if="filteredMembers.length > 0">
                        <div class="panel-content">

                          <DynamicTable :data="filteredMembers" :columns="individuColumns" uniqueKey="indiv_id"
                            @update="handleIndividuUpdate" />

                        </div>
                      </template>





                      <div v-for="question in questionsTree.permanentChildren" :key="question.id">
                        <!-- Check for boolean questions with options -->
                        <template v-if="question.type === 'boolean'">
                          <p>{{ question.question }}</p>
                          <div class="p-buttonset">
                            <Button v-for="option in question.options || ['Yes', 'No']" :key="option"
                              @click="setAnswer(question.id, option)" size="small">
                              {{ option }}
                            </Button>
                          </div>
                          <!-- Render guests table when "Yes" is selected -->
                          <div v-if="answers[question.id] === 'Yes' && question.id === '7'">
                            <GuestTable :initialGuests="guests" @update-guests="updateGuestData" />
                          </div>
                        </template>
                      </div>
                      <div class="actions">
                        <Button label="Back" severity="secondary" icon="pi pi-arrow-left"
                          @click="activateCallback(1)" />



                        <Button label="Next" icon="pi pi-arrow-right" iconPos="right" @click="activateCallback(3)" />
                      </div>
                      </div>
                      
                  </Card>
                </StepPanel>






                <!-- Step 3: Autres / Nouvelles informations. -->
                <StepPanel v-slot="{ activateCallback }" :value="3">
                  <Card title=" Informations Supplémentaires:" icon="pi-id-card" class="form-steps">
                    <NewInfoSection :infoRows="infoRows" @update="updateNewInfoData" />
                    <Button label="Back" severity="secondary" icon="pi pi-arrow-left" @click="activateCallback(2)" />
                    <Button label="Submit" icon="pi pi-check" class="p-button-success" @click="handleSubmitAndPost" />
                  </Card>
                </StepPanel>



              </StepPanels>
            </Stepper>
          </div>

          <!-- Side Panel for Submission History and Current Answers -->
          <div v-show="!isUnavailable" class="side-panel flex-none">
            <aside class="sidebar">
              <h3>Answered Questions</h3>

              <!-- Foyer Section -->
              <div class="answer-section">
                <h4>Foyer</h4>
                <div v-for="(answer, key) in answers" :key="key">
                  <p><strong>{{ key }}:</strong> {{ answer }}</p>
                </div>
              </div>

              <!-- Individu Section -->
              <div class="answer-section">
                <h4>Individu</h4>
                <div v-for="(member, index) in members" :key="index" class="collapsible-section">
                  <details>
                    <summary @click="toggleSection('member', index)">
                      Member {{ index + 1 }} - {{ member.name || 'Unnamed' }}
                    </summary>
                    <div class="expanded-content">
                      <p><strong>Name:</strong> {{ member.name }}</p>
                      <p><strong>Age:</strong> {{ member.age }}</p>
                      <p><strong>Sex:</strong> {{ member.sex }}</p>
                      <p><strong>Activity:</strong> {{ member.activity }}</p>
                    </div>
                  </details>
                </div>
              </div>

              <!-- Poste Section -->
              <div class="answer-section" v-if="postes.length > 0">
                <h4>Poste</h4>
                <div v-for="(poste, index) in postes" :key="index" class="collapsible-section">
                  <details>
                    <summary @click="toggleSection('poste', index)">
                      Poste {{ index + 1 }} - {{ poste.chaine || 'Unnamed' }}
                    </summary>
                    <div class="expanded-content">
                      <p><strong>Chaine:</strong> {{ poste.chaine }}</p>
                    </div>
                  </details>
                </div>
              </div>

              <!-- Invité Section -->
              <div class="answer-section" v-if="guests.length > 0">
                <h4>Invité</h4>
                <div v-for="(guest, index) in guests" :key="index" class="collapsible-section">
                  <details>
                    <summary @click="toggleSection('guest', index)">
                      Guest {{ index + 1 }} - {{ guest.name || 'Unnamed' }}
                    </summary>
                    <div class="expanded-content">
                      <p><strong>Name:</strong> {{ guest.name }}</p>
                      <p><strong>Age:</strong> {{ guest.age }}</p>
                      <p><strong>Sex:</strong> {{ guest.sex }}</p>
                      <p><strong>Activity:</strong> {{ guest.activity }}</p>
                    </div>
                  </details>
                </div>
              </div>
            </aside>

          </div>

        </div>
      </div>
    </div>
  </div>


</template>

<script setup>
import { ref, onMounted, computed, getCurrentInstance, watch, nextTick } from 'vue';
import axios from 'axios';
import { useConfirm } from 'primevue/useconfirm';
import Card from './components/Card.vue';
import QuestionComponent from './components/QuestionComponent.vue';
import Stepper from 'primevue/stepper';
import StepList from 'primevue/steplist';
import StepPanels from 'primevue/steppanels';
import Step from 'primevue/step';
import StepPanel from 'primevue/steppanel';
import Button from 'primevue/button';
import InputText from 'primevue/inputtext';
import 'primeicons/primeicons.css';
import ConfirmDialog from 'primevue/confirmdialog';
import Select from 'primevue/select';
import 'primeflex/primeflex.css';
import TVQuestionnaire from './components/TVQuestionnaire.vue';
import NewInfoSection from './components/NewInfo.vue';
import DynamicTable from "./components/DynamicTable.vue";
import Popover from "primevue/popover";
import GuestTable from "./components/GuestTable.vue";
import DatePicker from "primevue/datepicker";
import Toast from 'primevue/toast';
import select from 'primevue/select'
const placeholder = "Membres foyer";


const op = ref(null); // Popover reference

const tvCount = ref();
const isUnavailable = ref(false);
const unavailableReason = ref('');
const activeStep = ref(1);
const questionsTree = ref({}); // Load Foyer and Health questions dynamically
const answers = ref({});
const members = ref([]); // Array to store multiple members
const guests = ref([]); // Array to store multiple guests
const postes = ref([]); // Array to store multiple members
const currentPoste = ref({ chaine: '' });
const membreData = ref([]);
const posteData = ref([]);
const foyerData = ref({});
const currentFoyerIndex = ref(0);
const currentMemberIndex = ref(0);
const newInfoSection = ref(null);
const popoverVisible = ref(false);
const appointment = ref({ date: null });

const showGuestTable = ref(false);

const currentGuest = ref({ name: '', age: '', sex: '', activity: '' });
const Sex = ref(['Male', 'Femelle'])
const { proxy } = getCurrentInstance();
const tvData = ref([]);
const infoRows = ref([
  { information: "Nouvel équipement", detail: "" },
  { information: "Nouvelle adresse", detail: "" },
  { information: "Nouveau N° téléphone", detail: "" },
  { information: "Commentaires", detail: "" }, // New Comments field
]);

const individuColumns = ref([
  { field: "nom", header: "Nom", placeholder: "Enter Nom", editable: false },
  { field: "prenom", header: "Prénom", placeholder: "Enter Prénom", editable: false },
  { field: "age", header: "Age", placeholder: "Enter Age", editable: false },
  { field: "num_touche", header: "Num Touche", placeholder: "Enter Num Touche", editable: true },
]);

const handleIndividuUpdate = (updatedMember) => {
  formData.value.individu = updatedMember;

  console.log("Updated Individu:", updatedMember);
};
const postesColumns = ref([
  { field: "id_poste", header: "Poste ID", placeholder: "ID", editable: false },
  { field: "num_poste", header: "Numéro Poste", placeholder: "Enter Nom Poste" },
  { field: "emplacement", header: "Emplacement", placeholder: "Enter Type" },
]);
const handlePosteUpdate = (updatedPosteData) => {
  postes.value = updatedPosteData;
  console.log("Updated Poste Data:", updatedPosteData);
};



// Reactive object to hold editable fields
const editableFields = ref({
  nom: '',
  prenom: '',
  age: '',
  num_touche: '',
  chef_menage: '',
  maman: '',
  statut: '',
  niv_diplome: '',
  activite: ''
});


const toggleGuestTable = () => {
  showGuestTable.value = !showGuestTable.value;
};
const updateGuestData = (updatedGuests) => {
  formData.value.guests = updatedGuests;
  console.log("Updated guests:", updatedGuests);
};

const updatePosteData = (updatedPostes) => {
  formData.value.postes = updatedPostes;
  console.log("Updated postes:", updatedPostes);
};

const updateNewInfoData = (updatedNewInfo) => {
  formData.value.newInfo = updatedNewInfo;
  console.log("Updated new info:", updatedNewInfo);
};

const updateTVData = (updatedTVData) => {
  formData.value.tvData = updatedTVData;
  console.log("Updated TV data:", updatedTVData);
};


const setClientUnavailable = () => {
  isUnavailable.value = !isUnavailable.value;
  if (!isUnavailable.value) {
    unavailableReason.value = ""; // Reset the reason if toggled off
    popoverVisible.value = true; // Hide popover
  }
};

const updateAnswer = (questionId, value) => {
  nextTick(() => {
    answers.value[questionId] = value;
    console.log(`Answer updated for question ID ${questionId}:`, value);
  });
};


const toggle = (event) => {
  nextTick(() => {
    if (op.value) {
      op.value.toggle(event);
    }
  });
};



// Close Popover
const closePopover = () => {
  const popover = op.value;
  if (popover) popover.hide();
};

// Confirm Rendezvous
const confirmRendezvous = () => {
  if (!appointment.value.date) {
    // If no date is selected, show a warning
    proxy.$confirm.require({
      message: "Please select a valid date and time for the rendezvous.",
      header: "Error",
      icon: "pi pi-times-circle",
      acceptLabel: "OK",
      rejectVisible: false,
    });
    return;
  }

  console.log("Selected appointment date:", appointment.value.date);

  // Close the popover
  closePopover();

  // Show confirmation dialog
  proxy.$confirm.require({
    message: `Rendezvous scheduled successfully for ${appointment.value.date.toLocaleString()}.`,
    header: "Rendezvous Scheduled",
    icon: "pi pi-check-circle",
    acceptLabel: "OK",
    rejectVisible: false,
    accept: () => {
      console.log("Rendezvous confirmed."); // You can add further actions here if needed
    },
  });
};


const handleDelete = (deletedMember) => {
  console.log("Deleted Member:", deletedMember);
  // Logic to handle deletions
};



const setAnswer = (questionId, answer) => {
  answers.value[questionId] = answer;
  if (questionId === '2') {
    tvCount.value = parseInt(answer) || 0;
  }
};







const activateCallback = (step) => {
  activeStep.value = step;
  nextTick(() => {
    // Example: Explicit focus only when required
    const firstInput = document.querySelector('.step-panel input');
    if (firstInput) firstInput.focus();
  });
};


const addPoste = () => {
  if (postes.value.length >= 2) {
    proxy.$confirm.require({
      message: 'You can only add up to two "Poste".',
      header: 'Limit Reached',
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: 'OK',
      rejectVisible: false
    });
    return;
  }

  if (currentPoste.value.chaine) {
    postes.value.push({ ...currentPoste.value });
    currentPoste.value = { chaine: '' }; // Reset for next entry
  }
};

const addGuest = () => {
  if (currentGuest.value.name) {
    guests.value.push({ ...currentGuest.value });
    currentGuest.value = { name: '', age: '', sex: '', activity: '' }; // Reset for next entry
  }
};
const focusNextInput = (event) => {
  const currentInput = event.target;
  const formFields = Array.from(currentInput.closest('.panel-content').querySelectorAll('input'));
  const currentIndex = formFields.indexOf(currentInput);

  // Move focus to the next input field, if it exists
  if (currentIndex >= 0 && currentIndex < formFields.length - 1) {
    formFields[currentIndex + 1].focus();
  }
};
const expandedSection = ref({ type: null, index: null });

const toggleSection = (type, index) => {
  if (expandedSection.value.type === type && expandedSection.value.index === index) {
    expandedSection.value = { type: null, index: null }; // Collapse if already open
  } else {
    expandedSection.value = { type, index };
  }
};
const filteredMembers = computed(() => {
  if (membreData.value.length > 0 && foyerData.value.length > 0) {
    const currentFoyerID = foyerData.value[currentFoyerIndex.value]?.no_foyer;
    console.log("Filtering members with no_foyer:", currentFoyerID);
    return membreData.value.filter(member => member.no_foyer === currentFoyerID);
  }
  return [];
});
const filterePostes = computed(() => {
  if (posteData.value.length > 0 && foyerData.value.length > 0) {
    const currentFoyerID = foyerData.value[currentFoyerIndex.value]?.no_foyer;

    return posteData.value.filter(poste => poste.no_foyer === currentFoyerID);
  }
  return [];
});
// Ensure filtered members are updated dynamically
watch(
  () => filteredMembers.value,
  (members) => {
    members.forEach((member) => {
      // Ensure each row has its own editableFields entry
      if (!editableFields.value[member.id_indiv]) {
        editableFields.value[member.id_indiv] = { ...member };
      }
    });
  },
  { immediate: true }
);




watch(unavailableReason, async (newReason) => {
  if (newReason === "Pas Disponible/Prendre un rendez-vous") {
    await nextTick(); // Wait for DOM updates
    newInfoSection.value?.$el.scrollIntoView({ behavior: "smooth" });
  }
});





const handleSubmit = () => {
  console.log("Form Submitted:", {
    foyer: answers.value,
    individu: members.value,
    poste: postes.value,
    invite: guests.value,
    newInfo: infoRows.value, // Include the new information section

  });
  // Handle form data here (e.g., send to server)
  proxy.$confirm.require({
    message: 'Your form has been successfully created.',
    header: 'Success',
    icon: 'pi pi-check-circle',
    acceptLabel: 'OK',
    rejectVisible: false


  });
  if (currentFoyerIndex.value < foyerData.value.length - 1) {
    currentFoyerIndex.value++;
  } else {
    // Optionally show a message or reset to the first foyer
    alert('No more foyers available');
  }


};


const handleInfoRowsUpdate = (updatedRows) => {
  console.log("Updated infoRows from child:", updatedRows);
  infoRows.value = updatedRows; // Update parent data
};

const handleUpdate = (updatedMember) => {
  console.log("Updated Member:", updatedMember);
  // Logic to handle the updated member data
  const index = members.value.findIndex((m) => m.id_indiv === updatedMember.id_indiv);
  if (index !== -1) {
    members.value[index] = { ...updatedMember };
  }
};


// Update tvData method
const updateTvData = (data) => {
  tvData.value = data;
};
//----------------------------------------------------

const formData = ref({
  guests: [],
  individu: [],
  newInfo: [],
});


const fetchQuestionsTree = async () => {
  try {
    const response2 = await axios.get('http://localhost:8000/foyers');
    foyerData.value = response2.data
    formData.value.foyer = foyerData.value[currentFoyerIndex.value];

    const response3 = await axios.get('http://localhost:8000/membres')
    membreData.value = response3.data
    const response4 = await axios.get('http://localhost:8000/poste')
    posteData.value = response4.data
    const response = await axios.get('http://localhost:8000/questions-tree');
    questionsTree.value = response.data;
  } catch (error) {
    console.error('Error fetching questions:', error);
    alert('Failed to load foyer data. Please check the server.');

  }
};
const submitForm = async () => {
  try {
    console.log("Submitting form data:", formData.value);

    const response = await axios.post("http://localhost:8000/submit", formData.value);
    console.log("Form submitted successfully:", response.data);

    proxy.$confirm.require({
      message: 'Your form has been successfully submitted!',
      header: 'Success',
      icon: 'pi pi-check-circle',
      acceptLabel: 'OK',
      rejectVisible: false,
    });
  } catch (error) {
    console.error("Error submitting form:", error);
    proxy.$confirm.require({
      message: 'There was an error submitting your form. Please try again.',
      header: 'Error',
      icon: 'pi pi-times-circle',
      acceptLabel: 'OK',
      rejectVisible: false,
    });
  }
};

const handleSubmitAndPost = async () => {
  handleSubmit(); // Gather form data
  await submitForm(); // Send form data to the backend
};




onMounted(fetchQuestionsTree);
</script>

<style scoped>
.availability-check {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}

.unavailable-reason {
  margin-top: 10px;
}


.disabled-field {
  margin-right: 10px;
  opacity: 0.5;
  /* Grey out the disabled field */
  pointer-events: none;
}

.editable-field {
  margin-left: 10px;
}

#household-info-container {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 15px;
  margin-bottom: 20px;
  background-color: #f9fafe;
  border: 1px solid #e0e6ef;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
}

.p-buttonset {
  display: flex;
  gap: 5px;
  justify-content: center;
  /* Center-aligns the buttons if desired */

}



.main-content {
  flex-grow: 1;
  padding-right: 1rem;

}

.form-steps {
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  /* Horizontally centers content */
  padding: 1rem;
  gap: 1.5rem;
  /* Adds space between elements */
}



.actions {
  display: flex;
  justify-content: space-between;
  margin-top: 1rem;
}

.form-container {
  display: flex;
  flex-direction: row;
  gap: 1rem;
  width: 100%;

}

.centered-card {
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  /* Horizontally centers content */
  padding: 1rem;
  gap: 1.5rem;
  /* Adds space between elements */


}

/* Sidebar */
.sidebar {
  width: 300px;
  position: fixed;
  right: 0;
  top: 0;
  height: 100vh;
  padding: 1rem;
  background-color: #f9f9f9;
  border-left: 1px solid #e0e0e0;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  overflow-y: auto;
  z-index: 1000;
}

.sidebar h3 {
  font-size: 1.25rem;
  font-weight: bold;
  text-align: center;
  margin-bottom: 1rem;
}

.answer-section {
  margin-bottom: 1rem;
  padding: 1rem;
  background-color: #ffffff;
  border-radius: 6px;
  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.05);
}

.guest-table-section {
  background-color: #f9f9f9;
  padding: 1rem;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.05);
}

.answer-section h4 {
  font-size: 1rem;
  font-weight: bold;
  margin-bottom: 0.5rem;
}

.answer-section p {
  font-size: 0.95rem;
  color: #555;
  margin: 0;
}

.answer-section p strong {
  color: #333;
}

.collapsible-section summary {
  cursor: pointer;
  font-weight: 500;
  padding: 5px 0;
  color: #555;
  border-bottom: 1px solid #e0e0e0;
  transition: color 0.3s;
}

.collapsible-section summary:hover {
  color: #333;
}

.expanded-content {
  padding: 10px 15px;
  margin-top: 5px;
  background-color: #f0f2f5;
  border-radius: 8px;
  border-left: 3px solid #666;
}






.side-panel {
  width: 25%;
  /* Reduced side panel width */
  background-color: #f9f9f9;
  border-left: 1px solid #e0e0e0;
  padding: 1rem;
  box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.05);
  border-radius: 8px;
}

.side-panel h3 {
  font-size: 1.25rem;
  font-weight: bold;
  text-align: center;
  margin-bottom: 1rem;
}

.answer-section {
  margin-bottom: 1rem;
  padding: 1rem;
  background-color: #ffffff;
  border-radius: 6px;
  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.05);
}

.answer-section h4 {
  font-size: 1rem;
  font-weight: bold;
  margin-bottom: 0.5rem;
}

.answer-section p {
  font-size: 0.95rem;
  color: #555;
  margin: 0;
}

.answer-section p strong {
  color: #333;
}

.collapsible-section summary {
  cursor: pointer;
  font-weight: 500;
  padding: 5px 0;
  color: #555;
  border-bottom: 1px solid #e0e0e0;
  transition: color 0.3s;
}

.collapsible-section summary:hover {
  color: #333;
}

.expanded-content {
  padding: 10px 15px;
  margin-top: 5px;
  background-color: #f0f2f5;
  border-radius: 8px;
  border-left: 3px solid #666;
}

/* Adjusted color for links or highlighted text */
.answer-section a,
.answer-section .highlight {
  color: #444;
  font-weight: 600;
  text-decoration: none;
}

.answer-section a:hover,
.answer-section .highlight:hover {
  color: #222;
  text-decoration: underline;
}




/* Centered Foyer Info Card */
#foyerInfoCard {
  width: 100%;
  max-width: 800px;
  padding: 30px;
  background-color: #f9fafe;
  border: 1px solid #e0e6ef;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
}

.foyer-info-horizontal {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
  padding: 15px;
  background-color: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
}

@media screen and (max-width: 768px) {
  .content-wrapper {
    flex-direction: column;
  }

  .main-content {
    padding-right: 0;
  }

  .side-panel {
    width: 100%;
    margin-top: 20px;
  }
}

.foyer-info-item {
  flex: 1;
  font-size: 0.9rem;
  color: #333;
  font-family: Arial, sans-serif;
}

.foyer-info-item strong {
  font-weight: 600;
  color: #333;
}

.foyer-info-item span {
  color: #555;
}



.separator {
  height: 1px;
  background-color: #e0e0e0;
  margin: 15px 0;
}

.form-container {
  display: flex;
  flex-direction: row;
  gap: 1rem;
}

.unavailable-reason {
  margin-top: 1rem;
}

.popover-panel {
  max-width: 300px;
  background-color: white;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  padding: 1rem;
}

.p-button-text {
  margin-top: 0.5rem;
}

.Select {
  max-width: 300px;
}

.p-button-success {
  background-color: #4caf50 !important;
  /* Adjust green color */
  border-color: #4caf50 !important;
}

.p-button-danger {
  background-color: #f7f7f7 !important;
  /* Adjust red color */
  border-color: #f44336 !important;
}

.shadow-lg {
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1), 0 1px 3px rgba(0, 0, 0, 0.06);
}
</style>
